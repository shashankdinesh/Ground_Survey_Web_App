from django.shortcuts import render
from .models import Users, exampledata, datanew
from math import radians, cos, sin, asin, sqrt, atan2, degrees,pi
import xlsxwriter,xlrd,os

def mop(request):

    return render(request,'gui.html', {'title':'YOUR LOCATION'})


def signup(request):
    return render(request, 'register.html', {'title': 'REGISTER'})

def signin (request):
    londe = [[26, 78]]
    print('bahar')
    if request.method == 'POST':
        print('andar')
        name = request.POST.get('email', '')
        password = request.POST.get('pwd', '')
        print('agae a gaye',name, password)
        v=Users.object.all()
        print('ab nahi ghil raha')
        for i in v:
            if i.username==name and i.password==password:
                tokio = i.phone_number
                print(tokio,"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
                return render(request, 'search.html', {'title': 'SURVEYOR', 'l': londe,'to':i.phone_number})
    return render(request, 'gui.html', {'title': 'LOGIN'})

def register(request):
    londe = [[26, 78]]
    if request.method == 'POST':
        name = request.POST.get('email', '')
        password = request.POST.get('pwd', '')
        pnum = request.POST.get('phn', '')
        print(name,password,pnum)
        var=Users(username=name, password=password, phone_number=pnum)
        var.save()
        return render(request, 'search.html', {'title': 'SURVEYOR', 'l': londe,'to':pnum})
    else:
        return render(request, 'register.html', {'title': 'REGISTER'})


def latlonview(request):
    y,m=None,None
    latitude = []
    longitude = []
    ata=[]
    londe=[[26,78]]
    dictionary={}
    #print(request.method =='POST')
    if request.method =='POST':
        print("Point 1")
        lat=request.POST.get('lat','')
        lon = request.POST.get('lon', '')
        angle = request.POST.get('angle', '')
        distance = request.POST.get('distance', '')
        elevation = request.POST.get('elevation', '')
        print(lat,lon,angle,distance)
        point = datanew(lat=lat, lon=lon, ele=elevation)
        point.save()
        if lat !=None and lon !=None and len(distance)!=0 and len(angle)!=0:
            y,m=latlongenerator(float(distance), float(lat), float(lon), float(angle))
    sha=datanew.object.all()
    for a in sha:
        pla = a.lat
        plo = a.lon
        e=a.ele
        londe.append([pla,plo])
        ata.append([pla,plo,e])
    if y!=None and m!=None:
        londe.append([y,m])
    return render(request, 'usef.html',{'title':'YOUR LOCATION','l':londe})

def task(request):
    ata=[]
    londe = [[26, 78]]
    sha = datanew.object.all()
    for a in sha:
        pla = a.lat
        plo = a.lon
        e=a.ele
        ata.append([pla,plo,e])
    exelwrite(ata)
    file = 'C:/Users\Hp\Desktop\Expenses01.xlsx'
    os.startfile(file)
    return render(request, 'usef.html', {'title': 'YOUR LOCATION','l':londe})

def fview(request):
    y, m = None, None
    londe=[[26,78]]
    ata=[]
    toki=None
    if request.method == 'POST':
        lat = request.POST.get('lat', '')
        lon = request.POST.get('lon', '')
        angle = request.POST.get('angle', '')
        distance = request.POST.get('distance', '')
        elevation = request.POST.get('elevation', '')
        toki = request.POST.get('token1', '')
        print(lat, lon, angle, distance)
        point = exampledata(lat=lat, lon=lon, ele=elevation, distance=distance,ang=angle,chaturloki=toki)
        point.save()
        sha = exampledata.object.all()
        for a in sha:
            pla = a.lat
            plo = a.lon
            e = a.ele
            d=a.distance
            ang=a.ang
            londe.append([pla, plo])
            ata.append([pla, plo,e,d,ang])
    return render(request,'search.html', {'title':'YOUR LOCATION','l':londe,'to':toki})

def report(request):
    ata=[]
    londe=[[26,78]]
    toki=None
    if request.method == 'POST':
        toki = request.POST.get('token2', '')
    print(toki,"tokiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii")
    sha = exampledata.object.all()
    for a in sha:
        if a.chaturloki==toki:
            print("we are inside")
            pla = a.lat
            plo = a.lon
            e = a.ele
            d = a.distance
            ang = a.ang
            ho=a.chaturloki
            ata.append([pla, plo, e, d, ang])
    exelwrite1(ata)
    file = 'C:/Users\Hp\Desktop\Expenses02.xlsx'
    os.startfile(file)
    return render(request, 'search.html', {'title': 'YOUR LOCATION', 'l': londe,'to':toki})

def pview(request):
    y, m = None, None
    londe=[[26,78]]
    ata=[]
    toki=None
    if request.method == 'POST':
        lat = request.POST.get('lats', '')
        lon = request.POST.get('lons', '')
        elevation = request.POST.get('elevations', '')
        toki = request.POST.get('token', '')
        point = exampledata(lat=lat, lon=lon, ele=elevation, distance=0,ang=0,chaturloki=toki)
        point.save()
        sha = exampledata.object.all()
        for a in sha:
            pla = a.lat
            plo = a.lon
            londe.append([pla, plo])
    return render(request,'search.html', {'title':'YOUR LOCATION','l':londe,'to':toki})

def search(request):
    londe = [[26, 78]]
    return render(request,'search.html', {'title':'YOUR LOCATION','l':londe})


def latlongenerator(d,lat1,lon1,brng):
    R = 6371000
    distRatio = d/R
    distRatioSine = sin(distRatio)
    distRatioCosine = cos(distRatio)
    startLatRad = radians(lat1)
    startLonRad = radians(lon1)
    startLatCos = cos(startLatRad)
    startLatSin = sin(startLatRad)
    initialBearingRadians = radians(brng)
    endLatRads = asin((startLatSin * distRatioCosine) + (startLatCos * distRatioSine * cos(initialBearingRadians)))
    endLonRads = startLonRad+ atan2(sin(initialBearingRadians) * distRatioSine * startLatCos,distRatioCosine - startLatSin * sin(endLatRads))
    return degrees(endLatRads),degrees(endLonRads)


def exelwrite(ata):
    # Create a workbook and add a worksheet.
    workbook = xlsxwriter.Workbook('C:/Users\Hp\Desktop\Expenses01.xlsx')
    worksheet = workbook.add_worksheet()
    col1_name = 'S.NO:'
    col2_name = 'LATITUDE'
    col3_name = 'LONGITUDE'
    col4_name = 'ELEVATION'
    worksheet.write(0, 0, col1_name)
    worksheet.write(0, 1, col2_name)
    worksheet.write(0, 2, col3_name)
    worksheet.write(0, 3, col4_name)
    # Some data we want to write to the worksheet.
    row = 1
    col = 0
    for i in ata:
        worksheet.write(row, col, row)
        worksheet.write(row, col + 1,i[0])
        worksheet.write(row, col+2, i[1])
        worksheet.write(row, col + 3, i[2])
        row += 1

    workbook.close()

def exelwrite1(ata):
    # Create a workbook and add a worksheet.
    workbook = xlsxwriter.Workbook('C:/Users\Hp\Desktop\Expenses02.xlsx')
    worksheet = workbook.add_worksheet()
    col1_name = 'S.NO:'
    col2_name = 'LATITUDE'
    col3_name = 'LONGITUDE'
    col4_name = 'ELEVATION'
    col5_name = 'DISTANCE'
    col6_name = 'ANGLE'
    worksheet.write(0, 0, col1_name)
    worksheet.write(0, 1, col2_name)
    worksheet.write(0, 2, col3_name)
    worksheet.write(0, 3, col4_name)
    worksheet.write(0, 4, col5_name)
    worksheet.write(0, 5, col6_name)
    # Some data we want to write to the worksheet.
    row = 1
    col = 0
    for i in ata:
        worksheet.write(row, col, row)
        worksheet.write(row, col + 1,i[0])
        worksheet.write(row, col+2, i[1])
        worksheet.write(row, col + 3, i[2])
        worksheet.write(row, col + 4, i[3])
        worksheet.write(row, col + 5, i[4])
        row += 1

    workbook.close()