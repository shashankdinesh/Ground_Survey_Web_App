from django.apps import AppConfig


class SurveyingConfig(AppConfig):
    name = 'surveying'
